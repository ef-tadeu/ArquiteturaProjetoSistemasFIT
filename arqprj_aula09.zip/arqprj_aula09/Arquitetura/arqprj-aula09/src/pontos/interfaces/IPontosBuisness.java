package pontos.interfaces;

public interface IPontosBuisness {
	
	Participante find(int identificador);
}
